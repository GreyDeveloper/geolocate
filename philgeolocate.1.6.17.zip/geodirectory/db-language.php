<?php
/**
 * Translate language string stored in database. Ex: Custom Fields
 *
 * @package GeoDirectory
 * @since 1.4.2
 */

// Language keys